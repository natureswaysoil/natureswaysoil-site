
'use client'

import React from 'react'
import Link from 'next/link'
import { Leaf, Tag, ArrowRight } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Product } from '@/lib/types'

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const formatPrice = (price: number | null | undefined) => {
    return price ? `$${price.toFixed(2)}` : 'Contact for Price'
  }

  const getCategoryColor = (category: string | null | undefined) => {
    switch (category) {
      case 'Liquid Fertilizers':
        return 'bg-green-100 text-green-800'
      case 'Specialized Fertilizers':
        return 'bg-blue-100 text-blue-800'
      case 'Organic Supplements':
        return 'bg-purple-100 text-purple-800'
      case 'Soil Amendments':
        return 'bg-yellow-100 text-yellow-800'
      case 'Lawn Care':
        return 'bg-emerald-100 text-emerald-800'
      case 'Hydroponic Fertilizers':
        return 'bg-cyan-100 text-cyan-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <Card className="h-full hover:shadow-lg transition-shadow group">
      <CardHeader className="pb-4">
        {/* Product Image */}
        <div className="w-full aspect-square bg-gradient-to-br from-green-100 to-emerald-100 rounded-lg overflow-hidden mb-4 group-hover:from-green-200 group-hover:to-emerald-200 transition-colors">
          <img
            src={`/images/products/${product.id}.jpg`}
            alt={product.shortName || product.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            onError={(e) => {
              // Fallback to placeholder if image doesn't exist
              e.currentTarget.style.display = 'none';
              e.currentTarget.nextElementSibling?.classList.remove('hidden');
            }}
          />
          <div className="w-full h-full hidden items-center justify-center">
            <Leaf className="w-16 h-16 text-green-600" />
          </div>
        </div>
        
        <div className="space-y-2">
          {product.category && (
            <Badge className={getCategoryColor(product.category)}>
              {product.category}
            </Badge>
          )}
          <CardTitle className="text-lg text-gray-900 line-clamp-2">
            {product.shortName || product.title}
          </CardTitle>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="space-y-4">
          <CardDescription className="text-gray-600 line-clamp-3">
            {product.description || 'Premium organic product for healthy plant growth and soil improvement.'}
          </CardDescription>
          
          {product.features && (
            <div className="text-sm text-gray-500">
              <span className="font-medium">Features:</span> {product.features.split('•').slice(0, 2).join('•')}
            </div>
          )}
          
          <div className="flex items-center justify-between pt-4 border-t">
            <div className="flex items-center space-x-2">
              <Tag className="w-4 h-4 text-green-600" />
              <span className="text-lg font-bold text-green-600">
                {formatPrice(product.sellingPrice)}
              </span>
            </div>
            
            <Button asChild size="sm" className="bg-green-600 hover:bg-green-700">
              <Link href={`/products/${product.id}`}>
                View Details <ArrowRight className="ml-2 w-3 h-3" />
              </Link>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
