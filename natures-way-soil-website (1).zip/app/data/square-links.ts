
// Square payment links for products
// This would typically be configured with actual Square payment links

export interface SquareLink {
  productId: string
  squareUrl: string
}

// Example square links - replace with actual Square payment URLs
const squareLinks: SquareLink[] = [
  {
    productId: '1',
    squareUrl: 'https://natureswaysoil.com/order'
  },
  // Add more products as needed
]

export function getSquareLink(productId: string): string {
  const link = squareLinks.find(link => link.productId === productId)
  
  // Fallback to contact page if no specific link found
  return link?.squareUrl || '/contact'
}

// Helper to add square links
export function addSquareLink(productId: string, squareUrl: string): void {
  const existingIndex = squareLinks.findIndex(link => link.productId === productId)
  
  if (existingIndex >= 0) {
    squareLinks[existingIndex].squareUrl = squareUrl
  } else {
    squareLinks.push({ productId, squareUrl })
  }
}

export default squareLinks
